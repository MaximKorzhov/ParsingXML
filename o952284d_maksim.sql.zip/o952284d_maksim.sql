-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 11 2020 г., 15:32
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `o952284d_maksim`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--
-- Создание: Сен 11 2020 г., 08:34
-- Последнее обновление: Сен 11 2020 г., 11:56
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AVG_ROW_LENGTH=2730 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `category`, `parent_id`) VALUES
(1, 'Мобильные телефоны', 0),
(2, 'Apple', 1),
(3, 'Xiaomi', 1),
(4, 'Планшеты', 0),
(5, 'Samsung', 4),
(6, 'LG', 4),
(7, 'Sanyo', 1),
(8, 'Sony', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `offers`
--
-- Создание: Сен 11 2020 г., 12:13
-- Последнее обновление: Сен 11 2020 г., 12:30
--

DROP TABLE IF EXISTS `offers`;
CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(200) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `articul` varchar(255) NOT NULL,
  `picture` varchar(200) CHARACTER SET utf8 NOT NULL,
  `price` float NOT NULL,
  `optprice` float NOT NULL,
  `statusNew` int(11) NOT NULL,
  `statusAction` int(11) NOT NULL,
  `statusTop` int(11) NOT NULL,
  `url` varchar(200) CHARACTER SET utf8 NOT NULL,
  `color` varchar(100) CHARACTER SET utf8 NOT NULL,
  `available` int(11) NOT NULL,
  `vendor` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB AVG_ROW_LENGTH=2340 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `offers`
--

INSERT INTO `offers` (`id`, `category_id`, `name`, `description`, `articul`, `picture`, `price`, `optprice`, `statusNew`, `statusAction`, `statusTop`, `url`, `color`, `available`, `vendor`) VALUES
(1, 2, 'Apple Iphone 7', 'Описание товара', '1123123', 'http://www.shop.com/jpeg', 3000, 2000, 1, 0, 0, 'http://www.shop.com/detail.php?ID=1', 'Красный', 1, 'APPLE'),
(2, 3, 'Xiaomi Phone', 'Описание xiaomi', 'x912', 'http://www.shop.com/jpeg', 5000, 4000, 1, 1, 0, 'http://www.shop.com/detail.php?ID=2', 'Черный', 1, 'Xiaomi'),
(3, 5, 'Samsung Tablet', 'Описание samsung', 'st1912', 'http://www.shop.com/jpeg', 50000, 14000, 1, 1, 1, 'http://www.shop.com/detail.php?ID=3', 'Серый', 1, 'Samsung'),
(4, 6, 'LG tablet', 'Описание lg', 'lg4412', 'http://www.shop.com/jpeg', 3400, 400, 1, 0, 1, 'http://www.shop.com/detail.php?ID=4', 'Синий', 1, 'LG'),
(5, 8, 'Sony B2', 'Описание товара', '12121', 'http://www.shop.com/jpeg', 3000, 2000, 1, 0, 0, 'http://www.shop.com/detail.php?ID=1', 'Красный', 1, 'Sony'),
(6, 7, 'Sanyo Phone', 'Описание xiaomi', 'a234', 'http://www.shop.com/jpeg', 5000, 4000, 1, 1, 0, 'http://www.shop.com/detail.php?ID=2', 'Черный', 1, 'Sanyo'),
(7, 5, 'Samsung A7', 'Описание samsung', 'w456', 'http://www.shop.com/jpeg', 50000, 14000, 1, 1, 1, 'http://www.shop.com/detail.php?ID=3', 'Серый', 1, 'Samsung');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
